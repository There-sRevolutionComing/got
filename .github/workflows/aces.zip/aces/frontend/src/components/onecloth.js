import React from 'react'

function Onecloth(){
     
        return (
            <div>
                <h1>get cloth info by id</h1>
            </div>
        )
    }


export default Onecloth
