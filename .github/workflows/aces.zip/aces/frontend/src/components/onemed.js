import React from 'react'

function Onemed(){
     
        return (
            <div>
                <h1>get med info by id</h1>
            </div>
        )
    }


export default Onemed
