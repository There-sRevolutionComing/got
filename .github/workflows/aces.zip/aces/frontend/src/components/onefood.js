import React from 'react'

function Onefood(){
     
        return (
            <div>
                <h1>get food info by id</h1>
            </div>
        )
    }


export default Onefood
