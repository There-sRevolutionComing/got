import React from 'react'

function Onetoy(){
     
        return (
            <div>
                <h1>get toy
                 info by id</h1>
            </div>
        )
    }


export default Onetoy
