import React,{useEffect,useState} from "react"
import axios from "axios";
import {Link,useNavigate} from "react-router-dom"


function Takemed(){

  const navigate=useNavigate();
  
const[meds,setMeds]=useState([{
    name:'',
    purpose:'',
    quantity:null,
    expiry:''
}])

useEffect(() =>{
  if(!localStorage.getItem("authToken")){
      alert("Please login")
      navigate("/login");
  }

  const fetchData=async () =>{
      const config={
          headers:{
              authorisation:`Bearer ${localStorage.getItem("authToken")}`
          }
      }
      
      try {
          const {data}=await axios.get("http://localhost:5500/take/heal",config);
          console.log(data);
          setMeds(data);

      } catch (error) {
          localStorage.removeItem("authToken");
          alert("please login");
          console.log(error);
      }

      

  }

  fetchData();
},[navigate])




    return(
        <div className="container-fluid">
            <h1>Take medicines here</h1>
            <h2>Total number of meds:{meds.length}</h2>
            <div className="row">
           {meds.map((med,index) =>{
             return <div className="col-sm-4">
             <div className="card">
             <img src={`http://localhost:5500/${med.image}`} className="card-img-top" alt="..."/>
             <div className="card-body">
               <h5 className="card-title">Medicine name:{med.name}</h5>
               <p className="card-text">Used for:{med.purpose}</p>
               <p className="card-text">quantity:{med.quantity}</p>
               <p className="card-text">expiry date:{med.expiry}</p>
               <Link to={`/take/heal/${med._id}`} className="btn btn-primary">More info</Link>
             </div>
           </div>
           </div>
           })}
           </div>
            
        </div>

    )
}




export default Takemed;






//<div className="third ">
    //<img src={food_image} alt="" className="img_1" />
    //<div className="container1">

       // <h1>FEED WORLD</h1>
        //<p class="para">Leftover foods may not taste as delicious but it is still enough to feed the appetite of a burning stomach. It is more worthy to put in stomach than in refrigerator.   </p>
       // <a href="give/food" className="btn btn-primary">Donate</a>
   // </div>
//</div>