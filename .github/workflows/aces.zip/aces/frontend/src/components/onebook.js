import React from 'react'

function Onebook(){
     
        return (
            <div>
                <h1>get book info by id</h1>
            </div>
        )
    }


export default Onebook
