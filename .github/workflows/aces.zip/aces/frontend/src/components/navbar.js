import React, {useEffect,useState} from "react";
import {useNavigate} from "react-router-dom"
import "./navbar.css"
import axios from "axios";
import img from "./images/logoGOT-removebg-preview.png"


function Navbar(){
 const navigate=useNavigate();

 
  const logout = () =>{
    alert("confirm to logout");
   localStorage.removeItem("authToken");
    navigate("/");
  }

  
  const[user,setUser]=useState([{
      name:'',
      email:''
  
  }])
  
  
  
  useEffect(() =>{
     
  
      const fetchData=async () =>{
          const config={
              headers:{
                  authorisation:`Bearer ${localStorage.getItem("authToken")}`
              }
          }
          
          try {
              const {data}=await axios.get("http://localhost:5500/profile/user",config);
              console.log(data);
              setUser(data);
  
          } catch (error) {
              localStorage.removeItem("authToken");
              alert("please login");
              console.log(error);
          }
  
          
  
      }
  
      fetchData();
  },[navigate])
  
  
  
    return (
     
        <nav className="navbar">
              <div className="container">
             <a href="/">
                 <img src={img} alt="" className="align-text-top" />
                  </a>
                

       <ul className="nav justify-content-end">
        <li className="nav-item">
          {!localStorage.getItem("authToken")?( <a className="active btn a" aria-current="page" href="/login">Login</a>
          ) :
          (
            <button className="active btn a"  onClick={logout}>Welcome {user.username}</button>
          )}
         
        </li> 
        
      
 
     </ul>
      </div>
      </nav>
    )
}

export default Navbar;