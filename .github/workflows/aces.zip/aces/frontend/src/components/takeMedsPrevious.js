/*<form>
    <div className="form-group">
        <label for="Bookname">Book name</label>
        <input type="text" className="form-control" id="Bookname" placeholder="Enter name of book"
            onChange={event => {
                const { value } = event.target;
                setName(value);
            }} required /><br></br>

    </div>
    <div className="form-group">
        <label for="Publisher">Publisher</label>
        <input type="text" className="form-control" id="Publisher" placeholder="Publisher name"
            onChange={event => {
                const { value } = event.target;
                setPublisher(value);
            }} required /><br></br>  </div>
    <div className="form-group">
        <label for="Year">Publishing year</label>
        <input type="number" min="1500" className="form-control" id="Year" placeholder="Enter publishing year"
            onChange={event => {
                const { value } = event.target;
                setYear(value);
            }} required /><br></br>

    </div>
    <div className="form-group">
        <input type="file" className="form-control" name="image" onChange={event => {
            const file = event.target.files[0];
            setFile(file);
        }} /> <br></br>
    </div>
    <button type="submit" className="btn btn-primary"
        onClick={handleClick}>Give</button>
</form>-->*/
