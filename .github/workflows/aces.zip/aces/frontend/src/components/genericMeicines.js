import React, { useEffect, useState } from "react"
import axios from "axios";
import { Link, useNavigate } from "react-router-dom"
function Takemed1() {
return (
    <div>
    <h1>Generic Medicines</h1>
    <div class="ass">
        <h3>Generic Medicines Vs Branded Medicines</h3>
        <table width="100%">
            <thead>
                <tr>
                    <th >Generic</th>
                    <th >10 Tablets</th>
                    <th >Branded (Rs.)</th>
                    <th >Jan Aushadhi (Rs.)</th>
                    <th >Difference</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td >Antibiotic: Ciprofloxacin</td>
                    <td >250 mg</td>
                    <td align="center">54.79</td>
                    <td align="center">12.89</td>
                    <td align="center">4 times higher</td>
                </tr>
                <tr>
                    <td align="center">Pain Killer: Diclofenac</td>
                    <td align="center">100 mg</td>
                    <td align="center">60.40</td>
                    <td align="center">04.20</td>
                    <td align="center">14 times higher</td>
                </tr>
                <tr>
                    <td align="center">Common Cold: Cetrizine</td>
                    <td align="center">10 mg</td>
                    <td align="center">18.10</td>
                    <td align="center">02.75</td>
                    <td align="center">6 times higher</td>
                </tr>
                <tr>
                    <td align="center">Fever: Paracetamol</td>
                    <td align="center">500 mg</td>
                    <td align="center">09.40</td>
                    <td align="center">03.03</td>
                    <td align="center">3 times higher</td>
                </tr>
                <tr>
                    <td align="center">Pain and Fever: Nimesulids</td>
                    <td align="center">100 mg</td>
                    <td align="center">39.67</td>
                    <td align="center">03.16</td>
                    <td align="center">12 times higher</td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="boobs">
        <h3>Price List of Genric Medicins</h3>
        <table border="3" width="100%">
            <thead>
                <tr>
                    <th align="center">S.No.</th>
                    <th align="center">Drug Code</th>
                    <th align="center">Generic/Item</th>
                    <th align="center">Unit</th>
                    <th align="center">Price (MRP)</th>
                    <th align="center">Therapeutic Group</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td align="center">1</td>
                    <td align="center">1</td>
                    <td align="center">Aceclofenac 100mg and Paracetamol 325mg Tablets</td>
                    <td align="center">10's</td>
                    <td align="center">9.00</td>
                    <td align="center">Analgesics</td>
                </tr>
                <tr>
                    <td align="center">2</td>
                    <td align="center">2</td>
                    <td align="center">Aceclofenac Tablets IP 100 mg</td>
                    <td align="center">10's</td>
                    <td align="center">7.00</td>
                    <td align="center">Analgesics</td>
                </tr>
                <tr>
                    <td align="center">3</td>
                    <td align="center">3</td>
                    <td align="center"> Pregabalin Capsules IP 75 mg</td>
                    <td align="center">10's</td>
                    <td align="center">20.00</td>
                    <td align="center"></td>
                </tr>
                <tr>
                    <td align="center">4</td>
                    <td align="center">4</td>
                    <td align="center">Acetaminophen 325mg + Tramadol Hydrochloride 37.5mg film coated Tablet</td>
                    <td align="center">10's</td>
                    <td align="center">9.00</td>
                    <td align="center">Analgesics</td>
                </tr>
                <tr>
                    <td align="center">5</td>
                    <td align="center">5</td>
                    <td align="center">Aspirin Tablets IP 150 mg</td>
                    <td align="center">14's</td>
                    <td align="center">3.00</td>
                    <td align="center">Analgesics</td>
                </tr>
                <tr>
                    <td align="center">6</td>
                    <td align="center">6</td>
                    <td align="center">Chlorzoxazone 500mg, Diclofenac 50mg and Paracetamol 325mg Tablets</td>
                    <td align="center">10's</td>
                    <td align="center">15.00</td>
                    <td align="center">Analgesics</td>
                </tr>
                <tr>
                    <td align="center">7</td>
                    <td align="center">7</td>
                    <td align="center">Diclofenac Gel IP (Diclofenac Diethylamine 1.16%w/w)</td>
                    <td align="center">15 G</td>
                    <td align="center">12.00</td>
                    <td align="center">Analgesics</td>
                </tr>
                <tr>
                    <td align="center">8</td>
                    <td align="center">8</td>
                    <td align="center">Serratiopeptidase 10mg and Diclofenac Sodium 50mg Tablets</td>
                    <td align="center">10's</td>
                    <td align="center">14.00</td>
                    <td align="center">Analgesics and antipyretic /Muscle relaxant</td>
                </tr>
                <tr>
                    <td align="center">9</td>
                    <td align="center">9</td>
                    <td align="center">Chlorzoxazone 500mg, Diclofenac 50mg and Paracetamol 325mg Tablets</td>
                    <td align="center">10's</td>
                    <td align="center">11.00</td>
                    <td align="center">Analgesics</td>
                </tr>
                <tr>
                    <td align="center">10</td>
                    <td align="center">10</td>
                    <td align="center">Diclofenac Sodium Injection IP 25mg per ml</td>
                    <td align="center">3 MI</td>
                    <td align="center">4.00</td>
                    <td align="center">Analgesics</td>
                </tr>
                <tr>
                    <td align="center">11</td>
                    <td align="center">11</td>
                    <td align="center"> Diclofenac Gastro-Resistant Tablets IP 50 mg</td>
                    <td align="center">10's</td>
                    <td align="center">5.00</td>
                    <td align="center">Analgesics</td>
                </tr>
                <tr>
                    <td align="center">12</td>
                    <td align="center">12</td>
                    <td align="center"> Etoricoxib Tablets IP 120 mg</td>
                    <td align="center">10's</td>
                    <td align="center">35.00</td>
                    <td align="center">Analgesics</td>
                </tr>
                <tr>
                    <td align="center">13</td>
                    <td align="center">13</td>
                    <td align="center">Etoricoxib Tablets IP 90 mg</td>
                    <td align="center">10's</td>
                    <td align="center">28.00</td>
                    <td align="center">Analgesics</td>
                </tr>
                <tr>
                    <td align="center">14</td>
                    <td align="center">14</td>
                    <td align="center">Ibuprofen 400mg and Paracetamol 325mg Tablets IP</td>
                    <td align="center">10's</td>
                    <td align="center">7.00</td>
                    <td align="center"></td>
                </tr>
                <tr>
                    <td align="center">15</td>
                    <td align="center">15</td>
                    <td align="center"> Ibuprofen Tablets IP 200 mg</td>
                    <td align="center">10's</td>
                    <td align="center">3.00</td>
                    <td align="center"> Analgesic and antipyretic /Muscle relaxant</td>
                </tr>
                <tr>
                    <td align="center">16</td>
                    <td align="center">16</td>
                    <td align="center"> Etoricoxib Tablets IP 120 mg</td>
                    <td align="center">15's</td>
                    <td align="center">8.00</td>
                    <td align="center"></td>
                </tr>
            </tbody>
        </table>
    </div>
    </div>)
}
export default Takemed1;
