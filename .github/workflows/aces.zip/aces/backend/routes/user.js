const express=require('express');
const { protect } = require('./middleware/authmiddleware');
const userrouter=express.Router();
const User=require('./models/userModel')
const jwt=require("jsonwebtoken");

userrouter.get("/user",protect,(req,res,next)=>{
  const  token=req.headers.authorisation.split(" ")[1]
  const decoded=jwt.verify(token,process.env.JWT_SECRET);
   User.findById(decoded.id).exec()
   .then(doc =>{
       console.log(doc);
       res.json(doc);
   })
   .catch(err =>{
       console.log(err);
       res.json({error:err});
   })
});



module.exports=userrouter;