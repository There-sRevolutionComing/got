const express=require('express');

const takebookrouter=express.Router();
const {protect}=require('../middleware/authmiddleware');

const Book=require('../models/bookModel');

takebookrouter.get('/book',protect,(req,res,next)=>{
    Book.find({type:'Book'})
    .select('_id name type publisher year image')
    .exec()
    .then(data =>{
      
        res.json(data);
    })
    .catch(err => {
        console.log(err);
        res.json({error:err});
    });
   
});

takebookrouter.get('/book/:bookId',protect,(req,res,next)=>{
    const id=req.params.bookId;
   Book.findById(id).exec()
   .then(doc =>{
       console.log(doc);
       res.json(doc);
   })
   .catch(err =>{
       console.log(err);
       res.json({error:err});
   })
});

takebookrouter.post('/book/:bookId',protect,(req,res,next)=>{
    const takenbook={
        bookId:req.params.bookId,
        "name":req.body.name,
        "price":req.body.price
    }
    res.json({
        message:"you have successfully  taken book",
        "details":takenbook
    });
});





module.exports = takebookrouter;