const express=require('express');
const mongoose=require('mongoose');
const givebookrouter=express.Router();
const {protect}=require('../middleware/authmiddleware');
const multer=require('multer');
const path=require('path');
const storage=multer.diskStorage({
    destination:(req,file,cb) =>{
        cb(null,"bookUploads")
    },
    filename:(req,file,cb) =>{
        cb(null, Date.now()+path.extname(file.originalname))
    }
})
const Book=require('../models/bookModel');
const upload=multer({storage:storage});

givebookrouter.post('/book',protect,upload.single('image'),(req,res,next)=>{
   console.log(req.file);
     const book=new Book({
         _id: new mongoose.Types.ObjectId(),
         type:'Book',
         name:req.body.name,
         publisher:req.body.publisher,
         year:req.body.year,
        image:req.file.filename
      
     });
     book.save().then(result=>{
         console.log(result);
         res.json({
            message:"Donate books here",
            "Book details":book
        });

     }).catch(err=>{
         console.log(err);
         res.json({error:err});
     });
   
});





module.exports = givebookrouter;