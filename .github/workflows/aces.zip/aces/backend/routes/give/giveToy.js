const express=require('express');
const mongoose=require('mongoose');
const givetoyrouter=express.Router();
const {protect}=require('../middleware/authmiddleware');
const multer=require('multer');
const path=require('path');
const storage=multer.diskStorage({
    destination:(req,file,cb) =>{
        cb(null,"toyUploads")
    },
    filename:(req,file,cb) =>{
        cb(null, Date.now()+path.extname(file.originalname))
    }
})

const Toy=require('../models/toyModel');
const upload=multer({storage:storage});


givetoyrouter.post('/play',protect,upload.single('image'),(req,res,next)=>{
    console.log(req.file);
    const toy= new Toy({
        _id:new mongoose.Types.ObjectId(),
        type:'Toy',
        name:req.body.name,
        image:req.file.filename
    });
    toy.save().then(result=>{
        console.log(result);
        res.json({
            message:"Donate toys here",
            "toy details":toy
        });

    }).catch(err=>{
        console.log(err);
        res.json({error:err});
    });
   
});






module.exports = givetoyrouter;